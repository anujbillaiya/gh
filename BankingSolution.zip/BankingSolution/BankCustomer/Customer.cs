﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankCustomer
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }
        ServiceReference1.BankClient sb = new ServiceReference1.BankClient("NetTcpBinding_IBank");
        
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(sb.Increment());
        }
    }
}
