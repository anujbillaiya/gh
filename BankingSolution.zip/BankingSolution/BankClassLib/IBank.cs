﻿
using System.ServiceModel;

namespace BankClassLib
{
    [ServiceContract]
    public interface IBank
    {
        [OperationContract]
        string Deposit();
        [OperationContract]
        string Withdraw();
        [OperationContract]
        string Increment();
    }
}