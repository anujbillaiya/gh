﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace BankClassLib
{
 
    public class Bank : IBank
    {
        public int count = 0;
        public string Deposit()
        {
            return "Deposited At" + DateTime.Now.ToString();
        }

        public string Withdraw()
        {
            return "Deposited At" + DateTime.Now.ToString();
        }
        public string Increment()
        {
            return "Increment AT" + DateTime.Now.ToString()+" "+count++;
        }
    }
}
